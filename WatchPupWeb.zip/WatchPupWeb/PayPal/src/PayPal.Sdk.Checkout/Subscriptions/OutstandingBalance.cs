using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class OutstandingBalance
    {
        public string? currency_code { get; set; }
        public string? value { get; set; }
    }
}
