using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Subscription
    {
        [JsonPropertyName("id")]
        public string? ID { get; set; }

        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("status_update_time")]
        public DateTime?  StatusUpdateTime { get; set; }

        [JsonPropertyName("plan_id")]
        public string? PlanId { get; set; }

        [JsonPropertyName("plan_overridden")]
        public bool? PlanOverridden { get; set; }

        [JsonPropertyName("start_time")]
        public DateTime? StartTime { get; set; }

        [JsonPropertyName("quantity")]
        public string? Quantity { get; set; }

        [JsonPropertyName("shipping_amount")]
        public ShippingAmount? ShippingAmount { get; set; }

        [JsonPropertyName("subscriber")]
        public Subscriber? Subscriber { get; set; }

        [JsonPropertyName("create_time")]
        public DateTime? CreateTime { get; set; }

        [JsonPropertyName("links")]
        public Link[]? Links { get; set; }

        [JsonPropertyName("billing_info")]
        public BillingInfo? BillingInfo { get; set; }
    }
}
