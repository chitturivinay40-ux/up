using System;
using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Amount
    {
        public string? currency_code { get; set; }
        public string? value { get; set; }
    }
}
