using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions;

/// <summary>
/// The authorize an order request.
/// </summary>
public class AuthorizeRequest 
{
    /// <summary>
    /// The API caller-provided external ID for the purchase unit. Required for multiple purchase units.
    /// </summary>
    [JsonPropertyName("reference_id")]
    public string ReferenceId { get; set; } = null!;
}
