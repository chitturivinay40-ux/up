using System;
using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class BillingInfo
    {
        [JsonPropertyName("outstanding_balance")]
        public OutstandingBalance? OutstandingBalance { get; set; }

        [JsonPropertyName("cycle_executions")]
        public CycleExecutions[]? CycleExecutions { get; set; }

        [JsonPropertyName("last_payment")]
        public LastPayment? LastPayment { get; set; }

        [JsonPropertyName("next_billing_time")]
        public DateTime? NextBillingTime { get; set; }

        [JsonPropertyName("failed_payments_count")]
        public int? FailedPaymentsCount { get; set; }
    }
}
