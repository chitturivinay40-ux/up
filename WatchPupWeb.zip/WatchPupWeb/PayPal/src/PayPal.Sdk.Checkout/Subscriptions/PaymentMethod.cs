using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class PaymentMethod
    {
        [JsonPropertyName("payer_selected")]
        public string? PayerSelected { get; set; }

        [JsonPropertyName("payee_preferred")]
        public string? PayeePreferred { get; set; }
    }
}
