using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class ShippingAddress
    {
        [JsonPropertyName("name")]
        public Name1? Name { get; set; }

        [JsonPropertyName("address")]
        public Address? Address { get; set; }
    }
}
