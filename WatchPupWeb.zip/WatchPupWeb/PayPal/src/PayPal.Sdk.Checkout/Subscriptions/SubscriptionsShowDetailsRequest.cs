using PayPal.Sdk.Checkout.Core.HttpRequests;
using PayPal.Sdk.Checkout.Core.MessageSerializers;
using PayPal.Sdk.Checkout.Orders;
using PayPal.Sdk.Checkout.RequestInterfaces;
using System.IO;
using System;
using System.Net.Http;

namespace PayPal.Sdk.Checkout.Subscriptions;

    /// <summary>
    /// Creates an order. Supports only orders with one purchase unit.
    /// </summary>
public class SubscriptionsShowDetailsRequest: PayPalHttpRequest
    .WithJsonRequest<SubscriptionRequest>
    .WithJsonResponse<Subscription>,
    IConfigurePrefer, IConfigurePayPalPartnerAttributionId
{
    public SubscriptionsShowDetailsRequest(string subscriptionid) : base(
        "/v1/billing/subscriptions/{subscription_id}", HttpMethod.Get,
        PayPalSubscriptionJsonSerializerContext.CustomConverters.Subscription,
        PayPalSubscriptionJsonSerializerContext.CustomConverters.SubscriptionRequest
    )
    {
        try
        {
            Path = Path.Replace("{subscription_id}", Uri.EscapeDataString(Convert.ToString(subscriptionid)));
        }
        catch (IOException)
        {
        }
        ContentType = JsonMessageSerializer.ApplicationJson;
    }
}


