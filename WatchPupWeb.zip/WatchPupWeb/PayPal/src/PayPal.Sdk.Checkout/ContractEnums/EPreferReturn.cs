namespace PayPal.Sdk.Checkout.ContractEnums;

public enum EPreferReturn : byte
{
    Representation = 0,
    Minimal = 1,
}
