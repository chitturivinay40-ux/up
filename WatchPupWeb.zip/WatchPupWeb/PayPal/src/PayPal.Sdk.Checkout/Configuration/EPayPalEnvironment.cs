namespace PayPal.Sdk.Checkout.Configuration;

public enum EPayPalEnvironment : byte
{
    Sandbox = 0,
    Live = 1,
}
