using PayPal.Sdk.Checkout.Subscriptions;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Core.MessageSerializers;

[JsonSourceGenerationOptions(
    WriteIndented = true,
    PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase,
    GenerationMode = JsonSourceGenerationMode.Default
)]
[JsonSerializable(typeof(Subscription))]
[JsonSerializable(typeof(SubscriptionRequest))]
[JsonSerializable(typeof(AuthorizeRequest))]
internal partial class PayPalSubscriptionJsonSerializerContext : JsonSerializerContext
{
    private static PayPalSubscriptionJsonSerializerContext? _convertersContext;

    /// <summary>
    /// The default <see cref="global::System.Text.Json.Serialization.JsonSerializerContext"/> associated with a default <see cref="global::System.Text.Json.JsonSerializerOptions"/> instance.
    /// </summary>
    public static PayPalSubscriptionJsonSerializerContext CustomConverters => _convertersContext
        ??= new PayPalSubscriptionJsonSerializerContext(
            new JsonSerializerOptions(JsonSerializerOptionsForJsonSerializerContext.ConvertersContextOptions)
        );
}
