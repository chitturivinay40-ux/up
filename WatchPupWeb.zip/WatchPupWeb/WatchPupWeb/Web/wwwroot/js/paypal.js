﻿// wwwroot/js/paypal.js

//function initPayPalButton(clientId, planId, onApproveCallback) {
//    paypal.Buttons({
//        createSubscription: function (data, actions) {
//            return actions.subscription.create({
//                plan_id: planId
//            });
//        },
//        onApprove: function (data, actions) {
//            onApproveCallback();
//        }
//    }).render('#paypal-button-container');
//}

//   function f() {
//    // Load the PayPal JavaScript SDK asynchronously
//    const script = document.createElement('script');
//    script.src = 'https://www.paypal.com/sdk/js?client-id=ATxreRLP3Xh1pInwowKWaIAv3zjbzsEZZ24_aYUlRNRHXjfSorIN0XvoZKXbCnzr9WgRTIDILkwYqFF6';
//    script.async = true;
//    script.onload = () => {
//        // Optional: Perform actions once the script is loaded
//        console.log('PayPal SDK loaded.');
//    };
//    document.head.appendChild(script);
//}

