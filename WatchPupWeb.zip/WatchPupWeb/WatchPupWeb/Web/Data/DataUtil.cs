﻿using System.Text;

namespace WatchPupWeb.Data
{
    public static class DataUtil
    {
        public static string SiteName = "WatchPup";
        public static string UserName = string.Empty;
        public static string FirstName  = string.Empty;
        public static string LastName = string.Empty;
        public static string Environment = string.Empty;
        public static string CancelURL = string.Empty;
        public static string ReturnURL = string.Empty;
    }
}


