using DataAccessLibrary.Models;
using System;

namespace WatchPupWeb.Data
{
    public class GlobalVariables
    {
        public Int32 UserId { get; set; }
        public string UserName { get; set; }
        public Int32 SubscriptionId { get; set; }
        public string PPSubscriptionId { get; set; }
        public SubscriptionModel SubscriptionModel { get; set; }
        public string VerificationId { get; set; }
        public Int16 Verified { get; set; }
    }
}
