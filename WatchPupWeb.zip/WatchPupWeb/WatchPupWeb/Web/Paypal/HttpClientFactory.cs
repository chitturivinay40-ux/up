﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PayPal.Sdk.Checkout.Core.Interfaces;
using PayPal.Sdk.Checkout.Extensions;
using System;
using System.IO;

namespace WatchPupWeb.Paypal;

public static class HttpClientFactory
{
    private static IServiceProvider CreateServiceProvider()
    {
        //configurationBuilder.AddJsonFile("appsettings.json5", optional: false, reloadOnChange: false);
        //configurationBuilder.AddJsonFile("user.appsettings.json5", optional: true, reloadOnChange: false);
        var configurationBuilder = new ConfigurationBuilder();

        var currentDirectory = Directory.GetCurrentDirectory();
        configurationBuilder.SetBasePath(currentDirectory);
        //configurationBuilder.AddEnvironmentVariables();
        configurationBuilder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: false);

        var tempConfiguration = configurationBuilder.Build();
        configurationBuilder = new ConfigurationBuilder();
        configurationBuilder.SetBasePath(currentDirectory);
        if (tempConfiguration?.GetSection("Environment")?.Value == "Development")
        {
            configurationBuilder.AddJsonFile("appsettings.paypal.sandbox.json", optional: false, reloadOnChange: false);
        }
        else if (tempConfiguration?.GetSection("Environment")?.Value == "Production")
        {
            configurationBuilder.AddJsonFile("appsettings.paypal.live.json", optional: false, reloadOnChange: false);
        }

        var configuration = configurationBuilder.Build();
        var serviceCollection = new ServiceCollection();

        serviceCollection.AddPayPalCheckout(c => configuration.Bind(c));

        return serviceCollection.BuildServiceProvider();
    }

    public static IPayPalHttpClient CreateHttpClient()
    {
        var serviceProvider = CreateServiceProvider();

        return serviceProvider.GetRequiredService<IPayPalHttpClient>();
    }
}

