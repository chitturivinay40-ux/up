﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class UserEmailSettingModel
    {
        public Int32 UserId { get; set; }
        public Int32 EmailConfigId { get; set; }
    }
}
